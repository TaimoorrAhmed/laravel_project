Readme.txt

1. Install Laravel 8
.
2. Create a new database named as "laravel_project".
3. Import sql file to create tables "\Laravel\laravel_project.sql".
4. Run project.