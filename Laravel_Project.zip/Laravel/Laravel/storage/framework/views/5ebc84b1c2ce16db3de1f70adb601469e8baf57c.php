
<html>
	<body>
		<h1><center>THIS IS MY FIRST LARAVEL PAGE!!</center></h1>
	</body>
</html><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/index.blade.php ENDPATH**/ ?>