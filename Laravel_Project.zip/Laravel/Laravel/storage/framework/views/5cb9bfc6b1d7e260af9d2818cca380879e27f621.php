<?php

use \App\Http\Controllers\HomeController; ?>
<?php $__env->startSection('content'); ?>
<script>
function editUser() {
    var divId = document.getElementById('userDetail').style.visibility  = 'visible'
}
</script>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Dashboard')); ?></div>

                <div class="card-body" > 
                    <?php if(session('status')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('status')); ?>

                    </div>
                    <?php endif; ?>
                    <?php if(auth()->user()->is_admin == 0): ?>
                    <h1>Total User: <?php echo e($userCount); ?></h1>
                    <?php endif; ?>
                    


                    <br />
                    <table class="table table-hover">

                    
                    <?php if(auth()->user()->is_admin == 0): ?>
                        <thead>

                            <th>Avatar</th>

                            <th>Name</th>

                            <th>Email</th>

                            <th>Address</th>

                            <th>Phone Number</th>

                            <th>Created At</th>

                            <th>User Type</th>


                        </thead>
                        <?php elseif(auth()->user()->is_admin == 1): ?>
                        <thead>

                            <th>Name</th>

                            <th>Email</th>

                            <th>Address</th>

                            <th>Phone Number</th>

                            <th>Created At</th>

                            <th>User Type</th>


                        </thead>
                        <?php endif; ?>

                        <?php if(auth()->user()->is_admin == 0): ?>
                        <tbody>
                            <?php $__currentLoopData = $userDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>

                                <?php if($user->profile_picture_path == ""): ?>
                                <td> <img src="" alt="No preview Available" width="46" height="34"></td>
                                <?php elseif($user->profile_picture_path): ?>
                                <td> <img src="<?php echo e($user->profile_picture_path); ?>" alt="Avatar" width="46" height="34"></td>
                                <?php endif; ?>
                                <td><?php echo e($user->name); ?> </td>

                                <td><?php echo e($user->email); ?> </td>

                                <?php if($user->address == ""): ?>

                                <td> N/A </td>

                                <?php elseif($user->address): ?>

                                <td><?php echo e($user->address); ?> </td>

                                <?php endif; ?>


                                <?php if($user->phone_number == ""): ?>

                                <td> N/A </td>

                                <?php elseif($user->phone_number): ?>

                                <td><?php echo e($user->phone_number); ?> </td>

                                <?php endif; ?>


                                <td><?php echo e($user->created_at); ?> </td>

                                <?php if($user->is_admin == 0): ?>

                                <td> Admin </td>

                                <?php elseif($user->is_admin == 1): ?>

                                <td>Client </td>

                                <?php endif; ?>

                                <?php if($user->id == auth()->user()->id): ?>

                                <td><button onclick="editUser()">Edit</button></td>

                                <?php endif; ?>


                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                        <?php elseif(auth()->user()->is_admin == 1): ?>
                        <tbody >

                        <tr><img src="<?php echo e(auth()->user()->profile_picture_path); ?>" alt="Avatar" width="50%"></tr>
                           

                            <tr>
                                

                                <td><?php echo e(auth()->user()->name); ?> </td>

                                <td><?php echo e(auth()->user()->email); ?> </td>

                                <?php if(auth()->user()->address == ""): ?>

                                <td> N/A </td>

                                <?php elseif(auth()->user()->address): ?>

                                <td><?php echo e(auth()->user()->address); ?> </td>

                                <?php endif; ?>


                                <?php if(auth()->user()->phone_number == ""): ?>

                                <td> N/A </td>

                                <?php elseif(auth()->user()->phone_number): ?>

                                <td><?php echo e(auth()->user()->phone_number); ?> </td>

                                <?php endif; ?>


                                <td><?php echo e(auth()->user()->created_at); ?> </td>

                                <?php if(auth()->user()->is_admin == 0): ?>

                                <td> Admin </td>

                                <?php elseif(auth()->user()->is_admin == 1): ?>

                                <td>Client </td>

                                <?php endif; ?>

                                

                                <td><button onclick="editUser()">Edit</button></td>

                                


                            </tr>
                           

                        </tbody>
                        <?php endif; ?>
                        

                    </table>
                </div>
            </div>
            <div id="userDetail" style="visibility: hidden;"><h3>Edit Profile</h3>
                <form method="POST" action="/home" enctype="multipart/form-data">
                    <?php echo e(csrf_field()); ?>

                   
                    

                            <td>Update Profile Picture</td><br>
                            <td><input type="file" class="form-control" name="profile_picture_path" id="profile_picture_path"></td><br>
                    
                            <td>Name</td><br>
                            <td><input type="text" name="name"  value="<?php echo e(auth()->user()->name); ?>" />,</td><br>

                            <td>Email</td><br>
                            <td><input type="email" name="email"  value="<?php echo e(auth()->user()->email); ?>" /></td><br>

                            <td>Address</td><br>
                            <td><input type="address" name="address"  value="<?php echo e(auth()->user()->address); ?>" /></td><br>

                            <td>Phone Number</td><br>
                            <td><input type="phone_number" name="phone_number"  value="<?php echo e(auth()->user()->phone_number); ?>" /></td><br>
                            
                            <td>New Password</td><br>
                            <td><input type="password" name="password" /></td><br>

                            <td>Confirm Password</td><br>
                            <td><input type="password" name="password_confirmation" /></td><br>

                            <td><button type="submit">Update</button></td><br>
                    
                </form>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Laravel\Laravel\resources\views/home.blade.php ENDPATH**/ ?>